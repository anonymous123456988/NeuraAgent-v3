def run(a):
    return {'ok': True}
