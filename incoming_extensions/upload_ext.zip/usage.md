## 第二扩展 用法
调用 ext_run(name=beta, args={...})
